#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 *@author sichu
 *@date ${YEAR}/${MONTH}/${DAY}
 **/
public interface ${NAME} {
}
