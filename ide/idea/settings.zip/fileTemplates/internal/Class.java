#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 *@author sichu huang
 *@since ${YEAR}/${MONTH}/${DAY} ${HOUR}:${MINUTE}
 */
public class ${NAME} {
}
