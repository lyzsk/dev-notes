#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 *
 *@author sichu huang
 *@date ${YEAR}/${MONTH}/${DAY}
 **/
public enum ${NAME} {
}
